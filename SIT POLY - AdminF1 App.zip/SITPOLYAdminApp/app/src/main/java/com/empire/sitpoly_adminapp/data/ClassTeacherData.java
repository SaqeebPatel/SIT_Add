package com.empire.sitpoly_adminapp.data;

public class ClassTeacherData {

    private String classTeacherName;

    public ClassTeacherData() {
    }

    public ClassTeacherData(String classTeacherName) {
        this.classTeacherName = classTeacherName;
    }

    public String getClassTeacherName() {
        return classTeacherName;
    }

    public void setClassTeacherName(String classTeacherName) {
        this.classTeacherName = classTeacherName;
    }
}
