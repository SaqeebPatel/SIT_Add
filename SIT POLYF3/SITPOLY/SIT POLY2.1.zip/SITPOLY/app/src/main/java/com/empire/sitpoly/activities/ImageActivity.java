package com.empire.sitpoly.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.empire.sitpoly.R;
import com.github.chrisbanes.photoview.PhotoView;

public class ImageActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image);

        String image = getIntent().getStringExtra("image");
        PhotoView imageView = findViewById(R.id.full_image);

        Glide.with(this).load(image).into(imageView);
    }
}